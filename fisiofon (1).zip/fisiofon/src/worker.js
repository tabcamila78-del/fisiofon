const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'content-type','Access-Control-Allow-Methods':'POST,OPTIONS'};
const BASE='Você é euclIAdes, assistente de estudos do FISIOFON (fisiologia aplicada à Fonoaudiologia), um senhor simpático e didático. Responda em português do Brasil, de forma curta e clara. Conteúdo educativo: nunca substitua avaliação clínica. A ausculta cervical, isoladamente, não confirma penetração ou aspiração.';
const SYS={chat:BASE,correct:BASE+' Corrija a resposta discursiva do aluno: dê nota de 0 a 10, aponte acertos, erros e uma resposta modelo curta.',quiz:BASE+' Gere questões de múltipla escolha. Responda SOMENTE com JSON válido, sem markdown: [{"q":"enunciado","o":["A","B","C","D"],"c":índice_da_correta,"e":"explicação curta"}]'};
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{...CORS,'content-type':'application/json'}});
export default{async fetch(req,env){const u=new URL(req.url);
if(u.pathname!=='/api/chat')return env.ASSETS.fetch(req);
if(req.method==='OPTIONS')return new Response(null,{headers:CORS});
if(req.method!=='POST')return J({error:'method'},405);
let b;try{b=await req.json()}catch{return J({error:'json'},400)}
const mode=SYS[b.mode]?b.mode:'chat';let messages;
if(mode==='quiz'){const n=Math.min(Math.max(+b.n||6,1),12),t=(Array.isArray(b.topics)?b.topics:[]).slice(0,6).join(', ').slice(0,300);messages=[{role:'user',content:`Gere ${n} questões de nível ${String(b.level||'Intermediário').slice(0,20)} sobre: ${t}.`}]}
else messages=(Array.isArray(b.messages)?b.messages:[]).slice(-10).filter(m=>(m.role==='user'||m.role==='assistant')&&typeof m.content==='string').map(m=>({role:m.role,content:m.content.slice(0,4000)}));
if(!messages.length||messages[0].role!=='user')return J({error:'messages'},400);
const model=env.MODEL||'gemini-2.5-flash';
const contents=messages.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.content}]}));
const gc={maxOutputTokens:mode==='quiz'?3000:900};if(mode==='quiz')gc.responseMimeType='application/json';
const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'x-goog-api-key':env.GEMINI_API_KEY,'content-type':'application/json'},body:JSON.stringify({systemInstruction:{parts:[{text:SYS[mode]}]},contents,generationConfig:gc})});
if(!r.ok)return J({error:'upstream'},502);const d=await r.json();
const text=((d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts)||[]).map(x=>x.text||'').join('');
if(!text)return J({error:'empty'},502);return J({text})}};
