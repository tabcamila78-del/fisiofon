# FISIOFON
Front-end estático em `public/` e Worker (Cloudflare) em `src/worker.js` que serve o site e a rota `/api/chat` (IA euclIAdes, Google Gemini).
## Publicar
1. `npm i -g wrangler` e `wrangler login`
2. `wrangler secret put GEMINI_API_KEY` (a chave fica só no Worker)
3. `wrangler deploy`
Teste local: `wrangler dev`. Sem o Worker, o site funciona com o banco local de questões; a IA fica indisponível.
## Pendente
Login, banco de dados, área da monitora e banco de questões maior (o progresso hoje fica no navegador).

Chave gratuita em https://aistudio.google.com/apikey. Para trocar de modelo, edite `MODEL` em `wrangler.toml`.
